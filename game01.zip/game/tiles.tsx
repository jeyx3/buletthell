<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="tiles" tilewidth="80" tileheight="80" tilecount="100" columns="10">
 <image source="images/tileset.png" width="800" height="800"/>
</tileset>
