import arcade

from pyglet.graphics import Batch


SCREEN_WIDTH = 1024
SCREEN_HEIGHT = 768
CAMERA_LERP = 0.1
TILE_SCALING = 0.5

class Player(arcade.Sprite):
    def __init__(self):
        super().__init__("images/player.png", 0.5)
        self.center_x = 128  # Примерные координаты
        self.center_y = 256
        self.direction = [0, 0]
        self.speed = 15

    def setup(self):
        pass

    def update(self, delta_time: float):
        self.center_x += self.direction[0] * self.speed
        self.center_y += self.direction[1] * self.speed


class Game(arcade.Window):
    def __init__(self):
        super().__init__(1024, 768, "My Arcade Game")

        arcade.set_background_color(arcade.color.BLACK)

        # Камеры: мир и GUI
        self.world_camera = arcade.camera.Camera2D()  # Камера для игрового мира
        self.gui_camera = arcade.camera.Camera2D()  # Камера для объектов интерфейса

        # Причина тряски — специальный объект ScreenShake2D
        self.camera_shake = arcade.camera.grips.ScreenShake2D(
            self.world_camera.view_data,  # Трястись будет только то, что попадает в объектив мировой камеры
            max_amplitude=15.0,  # Параметры, с которыми можно поиграть
            acceleration_duration=0.1,
            falloff_time=0.5,
            shake_frequency=10.0,
        )
        # Звук взрыва на будуще

        # Данные уровня
        self.tile_map = None

        # Слои с нашими спрайтами
        self.player_list = arcade.SpriteList()
        self.bomb_list = arcade.SpriteList()

        # Игрок
        self.player: arcade.Sprite | None = None

        # Границы мира (по карте)
        self.world_width = SCREEN_WIDTH
        self.world_height = SCREEN_HEIGHT

        # Батч для текста
        self.batch = Batch()
        self.text_info = arcade.Text(
            "WASD/стрелки — движение • Столкнись с красно‑серой «бомбой» (астероид) — камера дрожит",
            20, 20, arcade.color.BLACK, 14, batch=self.batch
        )

    def setup(self):

        self.player_list = arcade.SpriteList()
        self.wall_list = arcade.SpriteList()

        self.map_name = "map1.tmx"
        self.tile_map = arcade.load_tilemap(self.map_name, scaling=TILE_SCALING)

        self.wall_list = self.tile_map.sprite_lists["walls"]
        self.chests_list = self.tile_map.sprite_lists["chests"]
        self.exit_list = self.tile_map.sprite_lists["exit"]
        self.collision_list = self.tile_map.sprite_lists["collision"]

        self.world_width = int(self.tile_map.width * self.tile_map.tile_width * TILE_SCALING)
        self.world_height = int(self.tile_map.height * self.tile_map.tile_height * TILE_SCALING)

        self.player = Player()

        self.player_list.append(self.player)

        self.physics_engine = arcade.PhysicsEngineSimple(
            self.player, self.collision_list
        )

    def on_draw(self):
        """Отрисовка экрана."""
        self.clear()

        self.world_camera.use()
        self.wall_list.draw()
        self.chests_list.draw()
        self.exit_list.draw()
        self.player_list.draw()

    def on_update(self, dt: float):
        self.physics_engine.update()  # Обновляем тряску камеры

        self.player.update(dt)

        position = (
            self.player.center_x,
            self.player.center_y
        )
        self.world_camera.position = arcade.math.lerp_2d(  # Изменяем позицию камеры
            self.world_camera.position,
            position,
            CAMERA_LERP,  # Плавность следования камеры
        )

        self.text_bombs = arcade.Text(
            f"Бомб осталось: {len(self.bomb_list)}",
            20, 46, arcade.color.DARK_SLATE_GRAY, 14, batch=self.batch
        )

    def on_key_press(self, key, modifiers):
        if key == arcade.key.W:
            self.player.direction[1] = 1
        elif key == arcade.key.S:
            self.player.direction[1] = -1
        if key == arcade.key.A:
            self.player.direction[0] = -1
        if key == arcade.key.D:
            self.player.direction[0] = 1

    def on_key_release(self, key, modifiers):
        if key == arcade.key.W or key == arcade.key.S:
            self.player.direction[1] = 0
        if key == arcade.key.A or key == arcade.key.D:
            self.player.direction[0] = 0

def setup_game():
    game = Game()
    game.setup()
    return game


def main():
    setup_game()
    arcade.run()


if __name__ == "__main__":
    main()